tinyMCE.addI18n('hr', {
    'Insert an image from your computer': 'Ubaci sliku s računala',
    'Insert image': 'Ubaci sliku',
    'Choose an image': "Odaberi sliku",
    'You must choose a file': "Morate odabrati sliku",
    'Got a bad response from the server': "Loš odziv sa servera",
    "Didn't get a response from the server": "Nedobiven odziv sa servera",
    'Insert': "Ubaci",
    'Cancel': "Prekid",
    'Image description': "Opis slike"
});
